test = 3
testrange = range(1,test+1)
print(testrange)